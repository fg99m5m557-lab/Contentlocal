# ContentLocal — Deployment guide

## 1. Get an Anthropic API key
1. Go to https://console.anthropic.com and sign up.
2. Go to "API Keys" → "Create Key". Copy it (starts with `sk-ant-`).
3. Add billing details (pay-as-you-go — a few dollars covers thousands of generations).

## 2. Put this project on GitHub
1. Create a free account at https://github.com if you don't have one.
2. Create a new repository (e.g. `contentlocal`).
3. Upload all these files to it (GitHub's web interface lets you drag-and-drop files — no command line needed).

## 3. Deploy on Vercel
1. Go to https://vercel.com and sign up with your GitHub account (free).
2. Click "Add New Project", select your `contentlocal` repository, click "Import".
3. Before clicking Deploy, open "Environment Variables" and add:
   - Name: `ANTHROPIC_API_KEY`
   - Value: (paste the key from step 1)
4. Click "Deploy". In about a minute, you'll get a live URL like `contentlocal.vercel.app`.

## 4. Connect your own domain (optional, ~10€/year)
1. Buy a domain (e.g. on Namecheap or Google Domains).
2. In Vercel, go to your project → "Domains" → add your domain.
3. Follow Vercel's instructions to point your domain's DNS to Vercel (usually just adding one record).

## 5. Set up Stripe payments
1. Create a free account at https://stripe.com.
2. Go to "Payment Links" → "Create payment link".
3. Create one for €19/mo (Pro) and one for €39/mo (Unlimited), each as a recurring subscription.
4. Copy each payment link URL.
5. In `src/App.jsx`, find the `Pricing` section and replace the `alert(...)` actions with:
   `action: () => window.location.href = "YOUR_STRIPE_LINK_HERE"`
6. Push the change to GitHub — Vercel redeploys automatically.

## 6. Test it
Visit your live URL, run a generation, and confirm the Subscribe buttons take you to Stripe checkout.

That's it — no server to maintain, no database to manage. Vercel and Stripe handle the infrastructure.
