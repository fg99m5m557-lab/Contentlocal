import { useState, useEffect, useRef } from "react";

// ---------- Design tokens ----------
// Palette: "storefront awning" — deep spruce green, butter yellow, paper white, ink
const C = {
  spruce: "#1E4038",
  spruceDark: "#142B26",
  butter: "#F2C94C",
  paper: "#FBF9F4",
  ink: "#1A1A18",
  mist: "#E8E4DA",
  clay: "#B0533A",
};

const FONT_LINK = "https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Public+Sans:wght@400;500;600;700&display=swap";

// ---------- Sample posts for the hero typewriter ----------
const SAMPLES = [
  {
    biz: "Riverside Barbershop · Portland",
    text: "Fresh fade season is here. ✂️ Walk-ins welcome all week — first coffee's on us while you wait. Who's due for a cleanup?",
  },
  {
    biz: "Luna Yoga Studio · Austin",
    text: "New to yoga? Our Sunday beginner flow is judgment-free, slow-paced, and ends with 10 blissful minutes of rest. Mats provided. 🧘",
  },
  {
    biz: "Torres Plumbing · Chicago",
    text: "That dripping faucet costs you ~$60/year in water. We'll fix it in under an hour — same-day slots open this week. 🔧",
  },
];

const SECTORS = [
  "Fitness coach / personal trainer",
  "Restaurant / café",
  "Hair salon / barbershop",
  "Real estate agent",
  "Plumber / electrician / handyman",
  "Massage / wellness therapist",
  "Photographer",
  "Pet groomer / dog walker",
  "Other (describe below)",
];

const TONES = ["Professional", "Friendly & casual", "Premium & polished"];
const TYPES = ["Social media post", "Service description", "Customer email"];

export default function ContentLocal() {
  const [page, setPage] = useState("home"); // home | app
  const [freeLeft, setFreeLeft] = useState(3);

  return (
    <div style={{ background: C.paper, color: C.ink, minHeight: "100vh", fontFamily: "'Public Sans', sans-serif" }}>
      <link rel="stylesheet" href={FONT_LINK} />
      <style>{`
        .display { font-family: 'Fraunces', serif; }
        .btn-primary { background: ${C.butter}; color: ${C.ink}; border: 2px solid ${C.ink}; box-shadow: 3px 3px 0 ${C.ink}; transition: transform .12s, box-shadow .12s; }
        .btn-primary:hover { transform: translate(-1px,-1px); box-shadow: 4px 4px 0 ${C.ink}; }
        .btn-primary:active { transform: translate(2px,2px); box-shadow: 1px 1px 0 ${C.ink}; }
        .card { background: white; border: 2px solid ${C.ink}; box-shadow: 4px 4px 0 ${C.mist}; }
        input, select, textarea { outline: none; }
        input:focus, select:focus, textarea:focus { border-color: ${C.spruce} !important; }
        @media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
      `}</style>

      <Nav page={page} setPage={setPage} freeLeft={freeLeft} />
      {page === "home" ? (
        <Home goApp={() => setPage("app")} />
      ) : (
        <Generator freeLeft={freeLeft} setFreeLeft={setFreeLeft} goPricing={() => { setPage("home"); setTimeout(() => document.getElementById("pricing")?.scrollIntoView({ behavior: "smooth" }), 60); }} />
      )}
      <Footer />
    </div>
  );
}

// ---------- Nav ----------
function Nav({ page, setPage, freeLeft }) {
  return (
    <nav style={{ borderBottom: `2px solid ${C.ink}`, background: C.paper, position: "sticky", top: 0, zIndex: 20 }}>
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <button onClick={() => setPage("home")} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ width: 26, height: 26, background: C.spruce, borderRadius: "50% 50% 50% 4px", display: "inline-block", border: `2px solid ${C.ink}` }} />
          <span className="display" style={{ fontWeight: 700, fontSize: 20 }}>ContentLocal</span>
        </button>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          {page === "app" && (
            <span style={{ fontSize: 13, fontWeight: 600, background: C.mist, padding: "4px 10px", borderRadius: 20 }}>
              {freeLeft} free left
            </span>
          )}
          <button className="btn-primary" onClick={() => setPage("app")} style={{ padding: "8px 16px", borderRadius: 8, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
            {page === "app" ? "Generating" : "Try it free"}
          </button>
        </div>
      </div>
    </nav>
  );
}

// ---------- Home ----------
function Home({ goApp }) {
  return (
    <main>
      <Hero goApp={goApp} />
      <HowItWorks />
      <Examples />
      <Pricing goApp={goApp} />
    </main>
  );
}

function Hero({ goApp }) {
  const [idx, setIdx] = useState(0);
  const [shown, setShown] = useState("");
  const sample = SAMPLES[idx];

  useEffect(() => {
    setShown("");
    let i = 0;
    const t = setInterval(() => {
      i++;
      setShown(sample.text.slice(0, i));
      if (i >= sample.text.length) {
        clearInterval(t);
        setTimeout(() => setIdx((idx + 1) % SAMPLES.length), 2600);
      }
    }, 22);
    return () => clearInterval(t);
  }, [idx]);

  return (
    <section style={{ background: C.spruce, color: C.paper, borderBottom: `2px solid ${C.ink}` }}>
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "64px 20px 72px", display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 48, alignItems: "center" }}>
        <div>
          <p style={{ letterSpacing: 2, fontSize: 12, fontWeight: 700, color: C.butter, textTransform: "uppercase", marginBottom: 16 }}>
            For local businesses
          </p>
          <h1 className="display" style={{ fontSize: "clamp(34px, 5vw, 52px)", lineHeight: 1.08, fontWeight: 700, margin: 0 }}>
            Never wonder what to post again.
          </h1>
          <p style={{ fontSize: 18, lineHeight: 1.6, marginTop: 18, color: "#D9E2DD", maxWidth: 440 }}>
            Tell us what you do and where. Get social posts, service descriptions, and customer emails written for your business — in 30 seconds.
          </p>
          <button className="btn-primary" onClick={goApp} style={{ marginTop: 28, padding: "14px 26px", borderRadius: 10, fontWeight: 700, fontSize: 16, cursor: "pointer" }}>
            Try it free — 3 generations on us
          </button>
          <p style={{ fontSize: 13, marginTop: 12, color: "#A8BCB3" }}>No signup. No credit card.</p>
        </div>

        {/* Signature: live post writing itself */}
        <div className="card" style={{ borderRadius: 14, padding: 22, color: C.ink, minHeight: 190 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
            <span style={{ width: 34, height: 34, borderRadius: "50%", background: C.butter, border: `2px solid ${C.ink}`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontFamily: "'Fraunces', serif" }}>
              {sample.biz[0]}
            </span>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14 }}>{sample.biz}</div>
              <div style={{ fontSize: 12, color: "#7A776E" }}>Just now · written by ContentLocal</div>
            </div>
          </div>
          <p style={{ fontSize: 15, lineHeight: 1.55, margin: 0, minHeight: 92 }}>
            {shown}
            <span style={{ borderLeft: `2px solid ${C.spruce}`, marginLeft: 2 }} />
          </p>
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { t: "Describe your business", d: "Your trade, your city, your vibe. Takes 20 seconds." },
    { t: "Pick what you need", d: "A social post, a service description, or an email to customers." },
    { t: "Copy and publish", d: "Get ready-to-use content. Regenerate until it sounds like you." },
  ];
  return (
    <section style={{ maxWidth: 1080, margin: "0 auto", padding: "64px 20px" }}>
      <h2 className="display" style={{ fontSize: 30, fontWeight: 700, marginBottom: 32 }}>How it works</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20 }}>
        {steps.map((s, i) => (
          <div key={i} className="card" style={{ borderRadius: 12, padding: 22 }}>
            <div style={{ fontFamily: "'Fraunces', serif", fontWeight: 700, fontSize: 20, color: C.spruce }}>{s.t}</div>
            <p style={{ marginTop: 8, lineHeight: 1.55, color: "#4B4A45", fontSize: 15 }}>{s.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Examples() {
  const ex = [
    { who: "Personal trainer, Denver", type: "Social post", text: "\"Monday motivation isn't about crushing it — it's about showing up. 20 minutes counts. Your future self says thanks. 💪\"" },
    { who: "Carpenter, Asheville", type: "Service description", text: "\"Custom shelving built to fit your space exactly — measured, crafted, and installed within two weeks. Local hardwood, honest quotes.\"" },
    { who: "Bistro, Lyon-style café", type: "Customer email", text: "\"We've missed you! This week only: bring a friend and dessert is on the house. Reply to book your table. 🍰\"" },
  ];
  return (
    <section style={{ background: C.mist, borderTop: `2px solid ${C.ink}`, borderBottom: `2px solid ${C.ink}` }}>
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "64px 20px" }}>
        <h2 className="display" style={{ fontSize: 30, fontWeight: 700, marginBottom: 8 }}>Written like a human. Made for your trade.</h2>
        <p style={{ color: "#55534C", marginBottom: 32 }}>Real examples generated for businesses like yours.</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 20 }}>
          {ex.map((e, i) => (
            <div key={i} className="card" style={{ borderRadius: 12, padding: 20 }}>
              <span style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, background: C.butter, padding: "3px 8px", borderRadius: 6, border: `1.5px solid ${C.ink}` }}>{e.type}</span>
              <p style={{ marginTop: 14, fontSize: 15, lineHeight: 1.6 }}>{e.text}</p>
              <p style={{ marginTop: 10, fontSize: 13, color: "#7A776E", fontWeight: 600 }}>{e.who}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing({ goApp }) {
  const plans = [
    { name: "Starter", price: "Free", detail: "3 generations to try it out", cta: "Start now", action: goApp, featured: false },
    { name: "Pro", price: "€19/mo", detail: "50 generations per month", cta: "Subscribe", action: () => alert("Stripe checkout goes here — connect your Stripe Payment Link when you deploy (takes ~15 min)."), featured: true },
    { name: "Unlimited", price: "€39/mo", detail: "Unlimited generations", cta: "Subscribe", action: () => alert("Stripe checkout goes here — connect your Stripe Payment Link when you deploy (takes ~15 min)."), featured: false },
  ];
  return (
    <section id="pricing" style={{ maxWidth: 1080, margin: "0 auto", padding: "64px 20px 80px" }}>
      <h2 className="display" style={{ fontSize: 30, fontWeight: 700, marginBottom: 32, textAlign: "center" }}>Simple pricing</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20, alignItems: "stretch" }}>
        {plans.map((p, i) => (
          <div key={i} className="card" style={{ borderRadius: 14, padding: 26, textAlign: "center", background: p.featured ? C.spruce : "white", color: p.featured ? C.paper : C.ink }}>
            <div style={{ fontWeight: 700, fontSize: 14, textTransform: "uppercase", letterSpacing: 1, color: p.featured ? C.butter : C.spruce }}>{p.name}</div>
            <div className="display" style={{ fontSize: 38, fontWeight: 700, margin: "10px 0 4px" }}>{p.price}</div>
            <p style={{ fontSize: 14, color: p.featured ? "#C9D6D0" : "#66645D", minHeight: 40 }}>{p.detail}</p>
            <button className="btn-primary" onClick={p.action} style={{ marginTop: 12, padding: "11px 22px", borderRadius: 9, fontWeight: 700, cursor: "pointer", width: "100%" }}>
              {p.cta}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
}

// ---------- Generator ----------
function Generator({ freeLeft, setFreeLeft, goPricing }) {
  const [sector, setSector] = useState(SECTORS[0]);
  const [custom, setCustom] = useState("");
  const [city, setCity] = useState("");
  const [tone, setTone] = useState(TONES[1]);
  const [type, setType] = useState(TYPES[0]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const lastPrompt = useRef(null);

  async function generate(regen = false) {
    if (freeLeft <= 0) { goPricing(); return; }
    setLoading(true); setError(""); setCopied(false);
    const business = sector.startsWith("Other") ? custom : sector;
    const prompt = `You are a marketing copywriter for small local businesses. Write ONE piece of content, nothing else — no preamble, no options, no explanations.

Business: ${business}${custom && !sector.startsWith("Other") ? ` — extra details: ${custom}` : ""}
Location: ${city || "a local neighborhood"}
Tone: ${tone}
Content type: ${type}

Rules: sound human and specific to this trade and place, keep it concise (a social post = 2-4 sentences max; an email = short with a subject line; a service description = one tight paragraph). Include at most 1-2 fitting emojis if the tone is casual, none if premium.${regen ? " Give a fresh, different angle from a typical first attempt." : ""}`;
    lastPrompt.current = prompt;
    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      });
      if (!res.ok) throw new Error("Request failed");
      const data = await res.json();
      const text = (data.text || "").trim();
      if (!text) throw new Error("Empty response");
      setResult(text);
      setFreeLeft(n => n - 1);
    } catch (e) {
      setError("Generation failed. Check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  function copy() {
    const ta = document.createElement("textarea");
    ta.value = result;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    document.body.removeChild(ta);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  const inputStyle = { width: "100%", padding: "12px 14px", borderRadius: 9, border: `2px solid ${C.ink}`, fontSize: 15, fontFamily: "inherit", background: "white", boxSizing: "border-box" };
  const labelStyle = { fontWeight: 700, fontSize: 13, textTransform: "uppercase", letterSpacing: 1, display: "block", marginBottom: 6, color: C.spruce };

  return (
    <main style={{ maxWidth: 760, margin: "0 auto", padding: "48px 20px 80px" }}>
      <h1 className="display" style={{ fontSize: 32, fontWeight: 700, marginBottom: 6 }}>Your content, ready in 30 seconds</h1>
      <p style={{ color: "#55534C", marginBottom: 28 }}>Fill this in once — then generate as many angles as you like.</p>

      <div className="card" style={{ borderRadius: 14, padding: 24, display: "grid", gap: 18 }}>
        <div>
          <label style={labelStyle}>Your business</label>
          <select value={sector} onChange={e => setSector(e.target.value)} style={inputStyle}>
            {SECTORS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label style={labelStyle}>{sector.startsWith("Other") ? "Describe your business" : "Anything specific? (optional)"}</label>
          <input value={custom} onChange={e => setCustom(e.target.value)} placeholder={sector.startsWith("Other") ? "e.g. Mobile bike repair service" : "e.g. We're running a spring promo"} style={inputStyle} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 14 }}>
          <div>
            <label style={labelStyle}>City / area</label>
            <input value={city} onChange={e => setCity(e.target.value)} placeholder="e.g. Brooklyn" style={inputStyle} />
          </div>
          <div>
            <label style={labelStyle}>Tone</label>
            <select value={tone} onChange={e => setTone(e.target.value)} style={inputStyle}>
              {TONES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label style={labelStyle}>Content type</label>
            <select value={type} onChange={e => setType(e.target.value)} style={inputStyle}>
              {TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <button className="btn-primary" disabled={loading} onClick={() => generate(false)} style={{ padding: "14px 24px", borderRadius: 10, fontWeight: 700, fontSize: 16, cursor: loading ? "wait" : "pointer", opacity: loading ? 0.7 : 1 }}>
          {loading ? "Writing…" : freeLeft > 0 ? `Generate my content (${freeLeft} free left)` : "Upgrade to keep generating"}
        </button>
      </div>

      {error && <p style={{ color: C.clay, fontWeight: 600, marginTop: 16 }}>{error}</p>}

      {result && (
        <div className="card" style={{ borderRadius: 14, padding: 24, marginTop: 24, background: C.spruce, color: C.paper }}>
          <div style={{ fontSize: 12, fontWeight: 700, textTransform: "uppercase", letterSpacing: 1, color: C.butter, marginBottom: 10 }}>Your {type.toLowerCase()}</div>
          <p style={{ whiteSpace: "pre-wrap", lineHeight: 1.65, fontSize: 16, margin: 0 }}>{result}</p>
          <div style={{ display: "flex", gap: 10, marginTop: 18, flexWrap: "wrap" }}>
            <button className="btn-primary" onClick={copy} style={{ padding: "10px 18px", borderRadius: 9, fontWeight: 700, cursor: "pointer" }}>
              {copied ? "Copied ✓" : "Copy"}
            </button>
            <button onClick={() => generate(true)} disabled={loading} style={{ padding: "10px 18px", borderRadius: 9, fontWeight: 700, cursor: "pointer", background: "transparent", color: C.paper, border: `2px solid ${C.paper}` }}>
              {loading ? "Writing…" : "Regenerate"}
            </button>
          </div>
        </div>
      )}

      {freeLeft <= 0 && (
        <div className="card" style={{ borderRadius: 14, padding: 22, marginTop: 24, textAlign: "center" }}>
          <p className="display" style={{ fontWeight: 700, fontSize: 20, margin: 0 }}>You've used your free generations</p>
          <p style={{ color: "#55534C", margin: "8px 0 14px" }}>Keep the momentum — plans start at €19/month.</p>
          <button className="btn-primary" onClick={goPricing} style={{ padding: "12px 22px", borderRadius: 9, fontWeight: 700, cursor: "pointer" }}>See plans</button>
        </div>
      )}
    </main>
  );
}

function Footer() {
  return (
    <footer style={{ borderTop: `2px solid ${C.ink}`, background: C.spruceDark, color: "#A8BCB3" }}>
      <div style={{ maxWidth: 1080, margin: "0 auto", padding: "28px 20px", display: "flex", flexWrap: "wrap", gap: 16, justifyContent: "space-between", fontSize: 13 }}>
        <span className="display" style={{ color: C.paper, fontWeight: 700, fontSize: 16 }}>ContentLocal</span>
        <span>Made for the businesses that make your neighborhood. · contact@contentlocal.app</span>
      </div>
    </footer>
  );
}
